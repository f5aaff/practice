# Random or not?

Use the ent tool in this directory (from
<http://www.fourmilab.ch/random/>) to assess the quality of the
randomness in the following samples:

RANDOM1

RANDOM2

RANDOM3

RANDOM4

RANDOM5

Try to figure out which sample(s) are good random bytes.

To use ent, run "make" to build the ent binary, and use it simply as:
$ ./ent RANDOM1 
etc.
