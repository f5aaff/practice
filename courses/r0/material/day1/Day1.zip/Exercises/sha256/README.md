# Secure Hash Algorithm 256 (SHA256)

Find the flaws in the SHA256 implementation and fix them. Use the test vectors
to verify your solution.
