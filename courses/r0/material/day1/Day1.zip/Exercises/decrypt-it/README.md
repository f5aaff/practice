# Decrypt it (hard)

The `ciphertext` was created using `challenge.py`, given a file `plaintext`, of
which you only know the beginning of the provided `plaintext.truncated`. Find the
complete plaintext!

Hint: Python thing
