# Entropytest

Use the script entropytest.sh to see how fast the "entropy" increases,
according to the Linux kernel's entropy estimator.

First run the script without doing nothing. Then start it again and try
to generate entropy on your machine, compare the time it takes for the
script to complete.
