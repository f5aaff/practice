# Solution

The solution is described in this post:
<https://research.kudelskisecurity.com/2020/06/17/audit-of-amis-hierarchical-threshold-signature-scheme/>

The script forge.py creates a proof without using the private key, and
shows that it passes verification.

PS: the factors were
p=75985339922803060232175476481154108559342026976124145303413251097210740095991
q=108313985671572698942691153473753144282953518017287597729279028855013429375763
but you could not find them :)

