# Military-grade

Estimate the shortest and longest (approximately) RSA keys that can be generated with
openssl (openssl genrsa command).

Is it safe? If you were a designer of OpenSSL, what would you change?
Why do you think OpenSSL behaves this way?
