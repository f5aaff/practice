# Shamir secret-sharing

The utility ssss (<http://point-at-infinity.org/ssss/>) was used to
split a secret generated with keygen.py, but we forgot the
secret-sharing parameters.

Your goal:

1. Recover the secret (and the parameters)
2. Suggest an alternative algorithm to make it easier to verify the
correctness of the secret recovered
