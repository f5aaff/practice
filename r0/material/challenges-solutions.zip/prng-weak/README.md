# Weak PRNG

Find the problems in the PRNG in `prng.c`, which generates random words.
