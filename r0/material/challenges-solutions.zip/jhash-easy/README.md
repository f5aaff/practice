# jhash easy

Find a collision for jhash <https://github.com/ysmood/jhash>, a
simplistic non-cryptographic hash. Not really sure where it's used or
whether it's used at all :)

The current directory includes jhash.c, as well as a Java version
jhash.java.

Solved it? Now go to the `jhash_hard` challenge
