# Weak DRBG

#### Requirements

- [python3](https://www.python.org)

#### Exercise

Find the problems in the deterministic random bit generator (DRBG) in
`drbg.py`.
