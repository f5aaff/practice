
In fact, all three samples are true, high-quality random bytes. The
discrepancy comes from the size of the sample (10KB vs 100KB vs 1MB),
and from the variability of statistics (RANDOM3 vs RANDOM4).

Even RANDOM5 contains high-quality randomness, but expressed in base64
rather than raw bytes :-)
